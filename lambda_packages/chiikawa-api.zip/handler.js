exports.lambdaHandler = async () => ({
  statusCode: 200,
  body: JSON.stringify({ message: "placeholder - deploy via CI/CD" }),
});
